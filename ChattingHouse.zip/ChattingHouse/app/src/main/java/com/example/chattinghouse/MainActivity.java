package com.example.chattinghouse;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        FirebaseAuth auth = FirebaseAuth.getInstance();
        final FirebaseUser firebaseUser = auth.getCurrentUser();
        TextView textView = findViewById( R.id.t1 );
        Typeface typeface = Typeface.createFromAsset( getAssets(), "fonts/LCALLIG.TTF" );
        textView.setTypeface( typeface );

        Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep( 700 );

                    if (firebaseUser == null) {
                        Intent in = new Intent( MainActivity.this, Main2Activity.class );
                        startActivity( in );
                    } else {
                        Intent in = new Intent( MainActivity.this, Main3Activity.class );
                        startActivity( in );
                    }
                    finish();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
    }
}