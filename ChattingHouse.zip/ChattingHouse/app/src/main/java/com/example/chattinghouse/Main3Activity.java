package com.example.chattinghouse;

import android.content.Intent;
//import android.support.annotation.NonNull;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Main3Activity extends AppCompatActivity {

    EditText e1,e2,e3,e4,e5;
    Button b1,b2;
    FirebaseAuth fa;
    DatabaseReference dr;
    HashMap<String,String> data = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        getSupportActionBar().setTitle("Registration Details");
        fa=FirebaseAuth.getInstance();
        final FirebaseUser fu = fa.getCurrentUser();
        final String PhoneNumber=fu.getPhoneNumber();


        dr= FirebaseDatabase.getInstance().getReference().child("Userinfo").child(PhoneNumber);



        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        e3=findViewById(R.id.e3);
        e4=findViewById(R.id.e4);
        e5=findViewById(R.id.e5);
        b1=findViewById(R.id.b1);
       b2=findViewById(R.id.lo);

       b2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               FirebaseAuth.getInstance().signOut();


               Intent i=new Intent(Main3Activity.this,Main2Activity.class);
               startActivity(i);
              finish();
           }
       });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String s1,s2,s3,s4,s5;
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                s3=e3.getText().toString();
                s4=e4.getText().toString();
                s5=e5.getText().toString();



                if(s1.isEmpty()){
                    e1.setError("Please enter your name");

                }
                else if(s2.isEmpty()){
                    e2.setError("Please enter your city name");


                }
                else if(s3.isEmpty()){
                    e3.setError("Please enter your email-id");
                }
                else if (s4.isEmpty()) {
                    e4.setError("Please enter your password");
                }else if (s4.length() < 8) {
                    e4.setError("Please enter atleast 8 digit");

                }
               else if (s5.isEmpty()) {
                    e5.setError("Please re-enter your Password");
                }
                else if(!s4.equals(s5)){
                    e5.setError("Please confirm your password");
                }
                else{

                    data.put("name",s1);
                    data.put("cityname",s2);
                    data.put("email",s3);
                    data.put("passwordd",s4);
                    data.put("mobileno",PhoneNumber);
                    data.put("image","image1");




                          dataenter();
                    Intent inte=new Intent(Main3Activity.this,Main4Activity.class);
                    startActivity(inte);






                }

            }
        });


    }

    public void dataenter(){

        dr.setValue(data).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if(task.isSuccessful()){

                    Toast.makeText(getApplicationContext(),"task complete",Toast.LENGTH_LONG).show();

                }
                else{

                    Toast.makeText(getApplicationContext(),"connectivity error",Toast.LENGTH_LONG).show();

                }

            }
        });

    }
}
