package com.example.chattinghouse;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Listadeptor extends ArrayAdapter {

    List list = new ArrayList();

    public Listadeptor(Context context, int resource) {
        super( context, resource );
    }

    public void add(Model model) {
        super.add( model );
        list.add( model );

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View view;

        view = convertView;
        Handler hd;
        if (view == null) {

            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
            view = layoutInflater.inflate( R.layout.listitem, parent, false );

            hd = new Handler();

            hd.name = view.findViewById( R.id.textView );
            hd.cityname = view.findViewById( R.id.textView2 );
            hd.email = view.findViewById( R.id.textView3 );
            hd.Password = view.findViewById( R.id.textView4 );
            hd.mobileno = view.findViewById( R.id.textView5 );
            view.setTag( hd );

        } else {


            hd = (Handler) view.getTag();

        }
        final Model model = (Model) this.getItem( position );
        hd.name.setText( model.getName() );

        hd.email.setText( model.getEmail() );
        hd.cityname.setText( model.getCityname() );
        hd.Password.setText( model.getPasswordd() );
        hd.mobileno.setText( model.getMobileno() );

        view.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in = new Intent( getContext().getApplicationContext(), Main7Activity.class );

                in.putExtra( "mobileno", model.getMobileno() );
                getContext().startActivity( in );

            }
        } );

        return view;

    }

    @Override
    public Object getItem(int position) {
        return super.getItem( position );
    }

    public static class Handler {
        TextView name, cityname, email, Password, mobileno;


    }
}




